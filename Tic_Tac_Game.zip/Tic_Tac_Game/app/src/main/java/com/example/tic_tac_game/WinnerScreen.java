package com.example.tic_tac_game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;

public class WinnerScreen extends AppCompatActivity {

    TextView winnerShow;
    MediaPlayer winnerMusic;

    ImageView winDance,winnerImg;

    Intent winIntent,intent;

    int winnerCode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner_screen);

        winnerShow = (TextView)findViewById(R.id.winnerName);

        winDance = (ImageView) findViewById(R.id.winDance);

        winnerImg = (ImageView) findViewById(R.id.winner);

        Glide.with(this)
                .load(R.drawable.windance)
                .into(winDance);

        winIntent= getIntent();

        winnerCode = winIntent.getIntExtra("winName",-1);

        if(winnerCode==-1)
        {
            Glide.with(this)
                    .load(R.drawable.aww)
                    .into(winDance);

            winnerShow.setText("Awwwww....No...One Won");

            winnerImg.setVisibility(View.INVISIBLE);

            winnerMusic  = MediaPlayer.create(this,R.raw.nowin);
            winnerMusic.start();
        }

        else {

            Glide.with(this)
                    .load(R.drawable.windance)
                    .into(winDance);

            winnerShow.setText("Congratulations You won........");

            if(winnerCode==0)
            {
                winnerImg.setImageResource(R.drawable.circle);
            }
            else
                winnerImg.setImageResource(R.drawable.cross);

            winnerMusic = MediaPlayer.create(this, R.raw.yay);

            winnerMusic.start();
        }



    }

    public void onStart(View view)
    {
        winnerMusic.stop();
        winnerMusic.release();
        intent = new Intent(this,HomePage.class);
        startActivity(intent);
    }

    public void onReset(View view)
    {
        winnerMusic.stop();
        winnerMusic.release();
        intent = new Intent(this,MainActivity.class);
        intent.putExtra("chosenSymbol",winnerCode);
        startActivity(intent);

    }
}