package com.example.tic_tac_game;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.Duration;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    ImageView img,turnImg;
    TextView turnTxt;
    MediaPlayer moveMusic,errorMusic;

    int activePlayer=0;

    int[] gameState;

    int moveCount=0,chosenSymbol;

    String winName;

    int [][]winningPositions= {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}}; // these are winning positions

    Bundle bundle;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        moveMusic= MediaPlayer.create(this,R.raw.move);
        errorMusic= MediaPlayer.create(this,R.raw.error);

        gameState = new int[9];

        Arrays.fill(gameState,-1);

        Intent intent = getIntent();

        chosenSymbol = intent.getIntExtra("chosenSymbol",-1);

        turnImg = (ImageView)findViewById(R.id.turnImage);
        turnTxt = (TextView) findViewById(R.id.turnNotify);

        turnTxt.setText("Your Turn");

        if(chosenSymbol==0)
            turnImg.setImageResource(R.drawable.circle);
        else {
            turnImg.setImageResource(R.drawable.cross);
            activePlayer = 1;
        }


    }

    public void ButtonPressed(View view)
    {
        int ViewId = view.getId(); // getting id of the view

        img =  (ImageView) findViewById(ViewId); // getting  imageView from id

        if(activePlayer==0)
        {
            if(img.getDrawable()==null) {
                moveCount++;
                turnTxt.setText("Your turn ");
                turnImg.setImageResource(R.drawable.cross);
                String loc = (String)view.getTag();
                int index = Integer.parseInt(loc);
                gameState[index]=0;
                img.animate().translationYBy(5f);
                moveMusic.start();
                img.setImageResource(R.drawable.circle);
                winnerCheck();
                activePlayer = 1;
            }
            else
                errorMusic.start();
        }

        else
        {
            if(img.getDrawable()==null) {
                moveCount++;
                turnTxt.setText("Your turn ");
                turnImg.setImageResource(R.drawable.circle);
                String loc = (String)view.getTag();
                int index = Integer.parseInt(loc);
                gameState[index]=1;
                img.animate().translationYBy(5f);
                moveMusic.start();
                img.setImageResource(R.drawable.cross);
                winnerCheck();
                activePlayer = 0;
            }
            else
                errorMusic.start();
        }
    }

    public void winnerCheck()
    {
        if(moveCount==9)
        {
            Intent intent = new Intent(this,WinnerScreen.class);
            intent.putExtra("winName",-1);
            startActivity(intent);
        }
        for(int [] row:winningPositions)
        {
            if(gameState[row[0]]==activePlayer && gameState[row[1]]==activePlayer && gameState[row[2]]==activePlayer)
            {
                Intent intent = new Intent(this,WinnerScreen.class);
                intent.putExtra("winName",activePlayer);
                moveMusic.stop();
                errorMusic.stop();
                moveMusic.release();
                errorMusic.release();
                startActivity(intent);
            }
        }
    }
}