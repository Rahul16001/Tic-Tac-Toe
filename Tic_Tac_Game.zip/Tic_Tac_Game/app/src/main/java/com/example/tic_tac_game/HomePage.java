package com.example.tic_tac_game;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class HomePage extends AppCompatActivity {

    MediaPlayer homeMusic;

    int chosenSymbol=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        homeMusic = MediaPlayer.create(this,R.raw.home);

        homeMusic.setLooping(true);

        homeMusic.start();

    }

    public void onPause()
    {
        super.onPause();
        homeMusic.pause();
    }

    public void onResume()
    {
        super.onResume();
        homeMusic.start();
    }

    public void chosen(View view) {
        homeMusic.stop();

        chosenSymbol = Integer.parseInt(String.valueOf(view.getTag()));

        if(chosenSymbol!=-1) {
            Log.d(TAG,String.valueOf(view.getTag()));
            Intent intent = new Intent(this,MainActivity.class);
            intent.putExtra("chosenSymbol",chosenSymbol);
            homeMusic.stop();
            homeMusic.release();
            startActivity(intent);
        }

    }
}